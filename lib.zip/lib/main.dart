import 'package:flutter/material.dart';

void main() {
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Simple Calculator',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _display = '0';
  String _operand = '';
  double? _firstOperand;

  void _onDigitPressed(String digit) {
    setState(() {
      if (_display == '0') {
        _display = digit;
      } else if (_display.length < 8) {
        _display += digit;
      }
    });
  }

  void _onOperationPressed(String operation) {
    setState(() {
      _firstOperand = double.tryParse(_display);
      _operand = operation;
      _display = '0';
    });
  }

  void _calculateResult() {
    setState(() {
      double? secondOperand = double.tryParse(_display);
      if (_firstOperand != null && secondOperand != null) {
        switch (_operand) {
          case '+':
            _display = (_firstOperand! + secondOperand).toStringAsFixed(2);
            break;
          case '-':
            _display = (_firstOperand! - secondOperand).toStringAsFixed(2);
            break;
          case '*':
            _display = (_firstOperand! * secondOperand).toStringAsFixed(2);
            break;
          case '/':
            if (secondOperand == 0) {
              _display = 'ERROR';
            } else {
              _display = (_firstOperand! / secondOperand).toStringAsFixed(2);
            }
            break;
          default:
            _display = 'ERROR';
        }
        _firstOperand = null;
        _operand = '';
      }
      if (_display.length > 8) _display = 'OVERFLOW';
    });
  }

  void _clearAll() {
    setState(() {
      _display = '0';
      _firstOperand = null;
      _operand = '';
    });
  }

  Widget _buildButton(String label, {Color? color, Function()? onPressed}) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color ?? Colors.grey,
        fixedSize: const Size(70, 70),
        shape: const CircleBorder(),
      ),
      child: Text(
        label,
        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Simple Calculator')),
      body: Column(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16.0),
              alignment: Alignment.bottomRight,
              color: Colors.black,
              child: Text(
                _display,
                style: const TextStyle(
                  fontSize: 48,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Column(
            children: [
              for (var row in [
                ["1", "2", "3", "+"],
                ["4", "5", "6", "-"],
                ["7", "8", "9", "*"],
                ["C", "0", "=", "/"]
              ])
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: row.map((label) {
                    if (label == "C") {
                      return _buildButton(label, color: Colors.red, onPressed: _clearAll);
                    } else if (label == "=") {
                      return _buildButton(label, color: Colors.green, onPressed: _calculateResult);
                    } else if ("+-*/".contains(label)) {
                      return _buildButton(label, color: Colors.orange, onPressed: () => _onOperationPressed(label));
                    } else {
                      return _buildButton(label, onPressed: () => _onDigitPressed(label));
                    }
                  }).toList(),
                ),
            ],
          ),
        ],
      ),
    );
  }
}